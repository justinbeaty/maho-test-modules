<?php

class Basic_Mod_Model_A extends Mage_Core_Model_Abstract
{
    public function test() {
        return 'Test from Basic_Mod_Model_A';
    }
}
