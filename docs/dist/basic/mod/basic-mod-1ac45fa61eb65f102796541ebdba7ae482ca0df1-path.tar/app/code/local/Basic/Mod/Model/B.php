<?php

class Basic_Mod_Model_B extends Mage_Core_Model_Abstract
{
    static $test = 'test';
}
