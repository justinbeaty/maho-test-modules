<?php

class AW_Core_Model_Test extends Mage_Core_Model_Abstract
{
    public function test() {
        return 'Test from AW_Core_Model_Test';
    }
}
