<?php

class Modman_Simple_Block_Test extends Mage_Core_Block_Template
{
    public function _construct()
    {
        $this->setTemplate('modman/simple/test.phtml');
    }
}
