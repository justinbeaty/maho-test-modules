<?php

class Modman_Nolink_Model_Test extends Mage_Core_Model_Abstract
{
    public function test() {
        return 'test';
    }
}
