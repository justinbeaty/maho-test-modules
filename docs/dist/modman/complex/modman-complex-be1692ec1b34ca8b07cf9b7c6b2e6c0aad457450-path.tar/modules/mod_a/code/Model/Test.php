<?php

class Modman_ComplexA_Model_Test
{
    public function test()
    {
        return Mage::helper('modman_complex_a')->__('test');
    }
}
