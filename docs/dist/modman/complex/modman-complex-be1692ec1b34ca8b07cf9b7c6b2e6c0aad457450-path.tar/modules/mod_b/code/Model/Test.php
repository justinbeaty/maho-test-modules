<?php

class Modman_ComplexB_Model_Test
{
    public function test()
    {
        return Mage::helper('modman_complex_b')->__('test');
    }
}
